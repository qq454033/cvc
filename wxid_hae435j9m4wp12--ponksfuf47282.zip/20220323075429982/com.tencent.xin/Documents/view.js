<iConsoleWindow: 0x139f89d00; baseClass = UIWindow; frame = (0 0; 375 667); autoresize = W+H; gestureRecognizers = <NSArray: 0x282a19620>; layer = <UIWindowLayer: 0x2824d6900>>
   | <UIView: 0x139df7e80; frame = (0 0; 375 667); hidden = YES; autoresize = W+H; layer = <CALayer: 0x282447340>>
   |    | <UIView: 0x139df7ff0; frame = (0 20; 375 732); autoresize = W; layer = <CALayer: 0x282447360>>
   |    |    | <UIImageView: 0x139df97b0; frame = (0 -20; 375 667); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2824581c0>>
   |    | <UIView: 0x139df9400; frame = (0 582; 375 65); autoresize = W+TM; layer = <CALayer: 0x2824581e0>>
   |    |    | <FixTitleColorButton: 0x139df9980; baseClass = UIButton; frame = (20 18; 157.5 42); opaque = NO; autoresize = RM; layer = <CALayer: 0x2824582e0>>
   |    |    |    | <UIImageView: 0x139fb6eb0; frame = (0 0; 157.5 42); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28245e3e0>>
   |    |    |    | <UIButtonLabel: 0x139dfbb30; frame = (60.5 10; 37 22); text = '登录'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807e95e0>>
   |    |    |    |    | <_UILabelContentLayer: 0x28245e440> (layer)
   |    |    | <FixTitleColorButton: 0x139dfcc40; baseClass = UIButton; frame = (197.5 18; 157.5 42); opaque = NO; autoresize = LM; layer = <CALayer: 0x282458b40>>
   |    |    |    | <UIImageView: 0x139fb82c0; frame = (0 0; 157.5 42); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28245e000>>
   |    |    |    | <UIButtonLabel: 0x13b604080; frame = (60.5 10; 37 22); text = '注册'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807e99f0>>
   |    |    |    |    | <_UILabelContentLayer: 0x28245e4e0> (layer)
   |    | <UIButton: 0x139f8a590; frame = (287 20; 88 49); opaque = NO; autoresize = LM; layer = <CALayer: 0x282440a00>>
   |    |    | <UIButtonLabel: 0x139fe8830; frame = (15 16; 58 17); text = '简体中文'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807d61c0>>
   |    |    |    | <_UILabelContentLayer: 0x28245de00> (layer)
   | <UILayoutContainerView: 0x13b61e940; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x28258c700>>
   |    | <UITransitionView: 0x13b61f0e0; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; layer = <CALayer: 0x28258d500>>
   |    |    | <UIViewControllerWrapperView: 0x13b79ed70; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x28222b4c0>>
   |    |    |    | <UILayoutContainerView: 0x13b61b9c0; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; gestureRecognizers = <NSArray: 0x282b39680>; layer = <CALayer: 0x28246e0c0>>
   |    |    |    |    | <UINavigationTransitionView: 0x13b61d0e0; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; layer = <CALayer: 0x28258f200>>
   |    |    |    |    |    | <UIViewControllerWrapperView: 0x139d16950; frame = (0 0; 375 667); layer = <CALayer: 0x282288400>>
   |    |    |    |    |    |    | <UIView: 0x13c5b6d60; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x28256dfe0>>
   |    |    |    |    |    |    |    | <MMTableView: 0x13aff7800; baseClass = UITableView; frame = (0 0; 375 667); clipsToBounds = YES; gestureRecognizers = <NSArray: 0x2836888a0>; layer = <CALayer: 0x28256d6e0>; contentOffset: {0, -64}; contentSize: {375, 443}; adjustedContentInset: {64, 0, 0, 0}; dataSource: delegate[0x283688270], class[MMTableViewInfo]>
   |    |    |    |    |    |    |    |    | <UITableViewWrapperView: 0x13ab8f800; frame = (0 0; 375 667); gestureRecognizers = <NSArray: 0x28368a550>; layer = <CALayer: 0x2825d50c0>; contentOffset: {0, 0}; contentSize: {375, 667}; adjustedContentInset: {0, 0, 0, 0}>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13c566df0; baseClass = UITableViewCell; frame = (0 319; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2822615c0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13b7a04d0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836d38d0>; layer = <CALayer: 0x282261760>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x139d3ac40; baseClass = UILabel; frame = (15 11.5; 104 21); text = '微信安全中心'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x28073ee40>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c70a0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13ca4ef10; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28227a4c0>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13b75f540; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28227c940>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b621d20; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823c5f40>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13b6b8f60; baseClass = UITableViewCell; frame = (0 275; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2822466c0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x139f954d0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836d6af0>; layer = <CALayer: 0x282253920>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13c414100; baseClass = UILabel; frame = (15 11.5; 70 21); text = '微信密码'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x28073d450>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c4980> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13ca356f0; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28226c880>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13b7da7c0; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282260500>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b6d9e00; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823c3740>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13c552860; baseClass = UITableViewCell; frame = (0 231; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x28224ff20>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13ca2a7b0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836d4a20>; layer = <CALayer: 0x28224f460>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b7da070; baseClass = UILabel; frame = (15 11.5; 52 21); text = '声音锁'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x280729e00>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c6020> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMBadgeView: 0x13b7da2f0; baseClass = UIImageView; frame = (77 7; 49 30); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2823fafa0>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b7d5510; baseClass = UILabel; frame = (12.5 6.5; 24 15); text = 'new'; userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x28072a580>>
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13c8448a0; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282402420>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c4a4c60; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2822475a0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b7d5790; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823faa80>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b789f30; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823fa6e0>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13b7ae9a0; baseClass = UITableViewCell; frame = (0 167; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x28224c4c0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13c5838b0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836edaa0>; layer = <CALayer: 0x28224ff00>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b7643e0; baseClass = UILabel; frame = (15 11.5; 70 21); text = '邮箱地址'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x28072d810>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c5a20> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x13b75aef0; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28072eb20>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c7ec0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13ca84240; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28224c060>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c574880; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28224f7e0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b764660; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823fb000>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13b78e680; baseClass = UITableViewCell; frame = (0 123; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2822480a0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13ca197e0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836f87b0>; layer = <CALayer: 0x28224b5c0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b74ff20; baseClass = UILabel; frame = (15 11.5; 52 21); text = '手机号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x28072dc70>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c6cc0> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x13b7c08b0; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28072f430>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c61c0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13c5cedf0; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282232b60>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c5b0bb0; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28224de00>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b7501a0; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823c1f60>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13b7a74c0; baseClass = UITableViewCell; frame = (0 79; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x282248d60>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13c52dff0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2836fa760>; layer = <CALayer: 0x28224a320>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b7bbbd0; baseClass = UILabel; frame = (15 11.5; 45 21); text = 'QQ号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x28072fe30>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c72c0> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x13b7bbe50; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28072f200>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c53e0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13c510d60; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28224b700>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c588f00; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28224b920>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b7bc0f0; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823c1d40>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b7bc260; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823c1fe0>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x13b761cb0; baseClass = UITableViewCell; frame = (0 15; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x28223a4e0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x13c54aed0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2829714d0>; layer = <CALayer: 0x28223dd40>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13b7758e0; baseClass = UILabel; frame = (15 11.5; 52 21); text = '微信号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x280720050>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c78e0> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x13b775b60; baseClass = UILabel; frame = (293 0; 46 44); text = '未设置'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x280722300>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c67e0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x13c52e590; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28223ca60>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c58da50; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282248ae0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b762360; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823cc3c0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x13b7624d0; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2823cce60>>
   |    |    |    |    |    |    |    |    | <UIView: 0x13c55fff0; frame = (0 0; 375 15); layer = <CALayer: 0x2822e94c0>>
   |    |    |    |    |    |    |    |    | <_UIScrollViewScrollIndicator: 0x13c5e4450; frame = (3 597; 369 3); alpha = 0; autoresize = TM; layer = <CALayer: 0x282239ce0>>
   |    |    |    |    |    |    |    |    |    | <UIView: 0x13ca81c50; frame = (0 0; 369 3); layer = <CALayer: 0x28223bee0>>
   |    |    |    |    |    |    |    |    | <UIView: 0x13c4d1aa0; frame = (0 363; 375 60); autoresize = W; layer = <CALayer: 0x2823c5ba0>>
   |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x139d20b80; baseClass = UILabel; frame = (20 6; 335 34); text = '如果遇到帐号信息泄露、忘记密码、诈骗等帐号安全问题...'; autoresize = W; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28073c5f0>>
   |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2823c62e0> (layer)
   |    |    |    |    |    |    |    |    | <_UIScrollViewScrollIndicator: 0x13c5d4f70; frame = (369 163; 3 437); alpha = 0; autoresize = LM; layer = <CALayer: 0x282239920>>
   |    |    |    |    |    |    |    |    |    | <UIView: 0x13b787eb0; frame = (0 0; 3 437); layer = <CALayer: 0x28223a220>>
   |    |    |    |    |    |    |    | <MMLoadingView: 0x13b6ebe30; frame = (0 0; 375 667); hidden = YES; autoresize = W+H; layer = <CALayer: 0x282224480>>
   |    |    |    |    |    |    |    |    | <UIImageView: 0x13b6b77e0; frame = (127.5 273.5; 120 120); opaque = NO; autoresize = LM+RM+TM+BM; userInteractionEnabled = NO; layer = <CALayer: 0x2822246c0>>
   |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13b6f0e00; frame = (30 20; 60 60); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2822240e0>>
   |    |    |    |    |    |    |    |    |    | <UIActivityIndicatorView: 0x13b659110; frame = (30 17; 60 60); hidden = YES; layer = <CALayer: 0x2822258c0>>
   |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x13c454350; frame = (11 11; 37 37); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282224220>>
   |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x13c494e50; baseClass = UILabel; frame = (0 83; 120 25); text = '正在验证密码…'; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x280712210>>
   |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x28239f080> (layer)
   |    |    |    |    | <MMUINavigationBar: 0x13b61bb50; baseClass = UINavigationBar; frame = (0 20; 375 44); opaque = NO; autoresize = W; tintColor = UIDeviceRGBColorSpace 0 0 0 1; gestureRecognizers = <NSArray: 0x282b3f840>; layer = <CALayer: 0x28246d200>> forcedLegacyProvider
   |    |    |    |    |    | <_UIBarBackground: 0x13b61bdb0; frame = (0 -20; 375 64); userInteractionEnabled = NO; layer = <CALayer: 0x28246d940>>
   |    |    |    |    |    |    | <_UIBarBackgroundShadowView: 0x13b61c9d0; frame = (0 64; 375 0.5); layer = <CALayer: 0x28246af80>> clientRequestedContentView effect=none
   |    |    |    |    |    |    |    | <_UIBarBackgroundShadowContentImageView: 0x13b61cef0; frame = (0 0; 375 0.5); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x282455560>>
   |    |    |    |    |    |    | <UIVisualEffectView: 0x13b61c550; frame = (0 0; 375 64); layer = <CALayer: 0x28246ae80>> effect=none
   |    |    |    |    |    |    |    | <_UIVisualEffectBackdropView: 0x13b61cbb0; frame = (0 0; 375 64); autoresize = W+H; userInteractionEnabled = NO; layer = <UICABackdropLayer: 0x28246ab20>>
   |    |    |    |    |    |    |    | <_UIVisualEffectSubview: 0x13b61cd50; frame = (0 0; 375 64); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x282454760>>
   |    |    |    |    |    | <MMTitleView: 0x139d73d20; frame = (187 4; 1 36); layer = <CALayer: 0x282401700>>
   |    |    |    |    |    |    | <MMUILabel: 0x13b683430; baseClass = UILabel; frame = (-47 0; 95 36); text = '帐号与安全'; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x280713570>>
   |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x282225ee0> (layer)
   |    |    |    |    |    | <UIView: 0x13b7c4310; frame = (0 0; 58 44); tintColor = UIDeviceWhiteColorSpace 1 1; layer = <CALayer: 0x2825b4260>>
   |    |    |    |    |    |    | <MMBarButton: 0x13b722550; baseClass = UIButton; frame = (10 0; 48 44); opaque = NO; layer = <CALayer: 0x2825b4de0>>
   |    |    |    |    |    |    |    | <UIImageView: 0x13b7f95c0; frame = (0 7; 15 30); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282283060>>
   |    |    |    |    |    |    |    | <UIButtonLabel: 0x13c552f70; frame = (15 12.5; 33 20); text = '设置'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x280717b10>>
   |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x28223bba0> (layer)
   |    |    |    |    |    | <UIView: 0x13b61c0f0; frame = (0 -20; 375 64); userInteractionEnabled = NO; layer = <CALayer: 0x28246e1e0>>
   |    |    |    |    |    |    | <CAGradientLayer: 0x28246d220> (layer)
   |    |    |    |    |    | <UINavigationBarBackIndicatorView: 0x13b61c260; frame = (8 11.5; 13 21); alpha = 0; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28246afa0>>
   |    | <UITabBar: 0x13b61ead0; frame = (0 618; 375 49); hidden = YES; autoresize = W+TM; tintColor = UIDeviceRGBColorSpace 0.2 0.65098 1 1; gestureRecognizers = <NSArray: 0x282b57ed0>; layer = <CALayer: 0x28258d800>>
   |    |    | <_UIBarBackground: 0x13b61ef00; frame = (0 0; 375 49); userInteractionEnabled = NO; layer = <CALayer: 0x28258c2c0>>
   |    |    |    | <_UIBarBackgroundShadowView: 0x139db5c50; frame = (0 -0.5; 375 0.5); layer = <CALayer: 0x2825980e0>> clientRequestedContentView effect=none
   |    |    |    |    | <_UIBarBackgroundShadowContentImageView: 0x13b62ba90; frame = (0 0; 375 0.5); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x282598860>>
   |    |    |    | <UIImageView: 0x13b7b41b0; frame = (0 0; 375 49); userInteractionEnabled = NO; layer = <CALayer: 0x2822298a0>>
   |    |    | <UITabBarButton: 0x13b6206d0; frame = (96 1; 90 48); opaque = NO; layer = <CALayer: 0x28258c7e0>>
   |    |    |    | <UITabBarSwappableImageView: 0x13b620c40; frame = (31.5 6.5; 27 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x28258c740>>
   |    |    |    | <UITabBarButtonLabel: 0x13b620990; frame = (29.5 34.5; 31 12); text = '通讯录'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807e44b0>>
   |    |    |    |    | <_UILabelContentLayer: 0x282598d20> (layer)
   |    |    | <UITabBarButton: 0x13b620e40; frame = (190 1; 89 48); opaque = NO; layer = <CALayer: 0x282589a00>>
   |    |    |    | <UITabBarSwappableImageView: 0x13b6213b0; frame = (32.5 6.5; 23 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x282588b20>>
   |    |    |    | <UITabBarButtonLabel: 0x13b621100; frame = (34 34.5; 20.5 12); text = '发现'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807e4410>>
   |    |    |    |    | <_UILabelContentLayer: 0x282598c00> (layer)
   |    |    | <UITabBarButton: 0x13b6215b0; frame = (283 1; 90 48); opaque = NO; layer = <CALayer: 0x282589a80>>
   |    |    |    | <UITabBarSwappableImageView: 0x13b621b20; frame = (33 6.5; 23 23); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x282589aa0>>
   |    |    |    | <UITabBarButtonLabel: 0x13b621870; frame = (39.5 34.5; 10.5 12); text = '我'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x2807e40a0>>
   |    |    |    |    | <_UILabelContentLayer: 0x282598ac0> (layer)
   |    |    | <UITabBarButton: 0x139d20ff0; frame = (2 1; 90 48); opaque = NO; layer = <CALayer: 0x2825d8220>>
   |    |    |    | <UITabBarSwappableImageView: 0x139d05cb0; frame = (32 6.5; 25 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x2825d87c0>>
   |    |    |    | <UITabBarButtonLabel: 0x139d46ee0; frame = (34.5 34.5; 20.5 12); text = '微信'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28074b2a0>>
   |    |    |    |    | <_UILabelContentLayer: 0x2823e5560> (layer)
   |    |    |    | <_UIBadgeView: 0x139d428a0; frame = (52 2; 26 18); text = '47'; userInteractionEnabled = NO; layer = <CALayer: 0x2825dc2e0>>
   |    |    |    |    | <UILabel: 0x139d5ee30; frame = (5 1; 16 16); text = '47'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x28074bb10>>
   |    |    | <MMBadgeView: 0x13b621ea0; baseClass = UIImageView; frame = (49 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2825883a0>>
   |    |    |    | <MMUILabel: 0x13b6229c0; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x2807e3930>>
   |    |    |    |    | <_UILabelContentLayer: 0x2825988e0> (layer)
   |    |    | <MMBadgeView: 0x139de0ae0; baseClass = UIImageView; frame = (143 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28258be00>>
   |    |    |    | <MMUILabel: 0x13b622c40; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x2807eeb20>>
   |    |    |    |    | <_UILabelContentLayer: 0x2825988c0> (layer)
   |    |    | <MMBadgeView: 0x13b616610; baseClass = UIImageView; frame = (237 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28258bd20>>
   |    |    |    | <MMUILabel: 0x13b622ec0; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x2807ee080>>
   |    |    |    |    | <_UILabelContentLayer: 0x2825988a0> (layer)
   |    |    | <MMBadgeView: 0x13b616f10; baseClass = UIImageView; frame = (330 1; 20 20); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28258bc40>>
   |    |    |    | <MMUILabel: 0x13b623140; baseClass = UILabel; frame = (0 0; 0 0); hidden = YES; userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x2807eff70>>
   |    |    |    |    | <_UILabelContentLayer: 0x282598880> (layer)