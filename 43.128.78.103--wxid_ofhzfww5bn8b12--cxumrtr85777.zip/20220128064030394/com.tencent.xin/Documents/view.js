<iConsoleWindow: 0x105737bd0; baseClass = UIWindow; frame = (0 0; 375 667); autoresize = W+H; gestureRecognizers = <NSArray: 0x2807c64c0>; layer = <UIWindowLayer: 0x280994c00>>
   | <UIView: 0x1061b1de0; frame = (0 0; 375 667); hidden = YES; autoresize = W+H; layer = <CALayer: 0x28093efa0>>
   |    | <UIView: 0x1061b3960; frame = (0 20; 375 732); autoresize = W; layer = <CALayer: 0x28093efc0>>
   |    |    | <UIImageView: 0x1061b8bf0; frame = (0 -20; 375 667); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28093ffa0>>
   |    | <UIView: 0x1061b8dc0; frame = (0 582; 375 65); autoresize = W+TM; layer = <CALayer: 0x28093ffc0>>
   |    |    | <FixTitleColorButton: 0x1061b8f30; baseClass = UIButton; frame = (20 18; 157.5 42); opaque = NO; autoresize = RM; layer = <CALayer: 0x280913f80>>
   |    |    |    | <UIImageView: 0x1057b4370; frame = (0 0; 157.5 42); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280916f00>>
   |    |    |    | <UIButtonLabel: 0x1057e4ce0; frame = (60.5 10; 37 22); text = '登录'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282afe210>>
   |    |    |    |    | <_UILabelContentLayer: 0x280917c00> (layer)
   |    |    | <FixTitleColorButton: 0x1057e5910; baseClass = UIButton; frame = (197.5 18; 157.5 42); opaque = NO; autoresize = LM; layer = <CALayer: 0x280916800>>
   |    |    |    | <UIImageView: 0x1057bb7a0; frame = (0 0; 157.5 42); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280916ae0>>
   |    |    |    | <UIButtonLabel: 0x1057e8ae0; frame = (60.5 10; 37 22); text = '注册'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282afe620>>
   |    |    |    |    | <_UILabelContentLayer: 0x280916f80> (layer)
   |    | <UIButton: 0x1057ea190; frame = (287 20; 88 49); opaque = NO; autoresize = LM; layer = <CALayer: 0x280917180>>
   |    |    | <UIButtonLabel: 0x1061bffd0; frame = (15 16; 58 17); text = '简体中文'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282af1950>>
   |    |    |    | <_UILabelContentLayer: 0x2809168e0> (layer)
   | <UILayoutContainerView: 0x1057d97b0; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x280881860>>
   |    | <UITransitionView: 0x1168b6ca0; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; layer = <CALayer: 0x280881b40>>
   |    |    | <UIViewControllerWrapperView: 0x1061ebbc0; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x28099a0a0>>
   |    |    |    | <UILayoutContainerView: 0x1168bf5e0; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; gestureRecognizers = <NSArray: 0x2806419b0>; layer = <CALayer: 0x280958ce0>>
   |    |    |    |    | <UINavigationTransitionView: 0x1168c0a60; frame = (0 0; 375 667); clipsToBounds = YES; autoresize = W+H; layer = <CALayer: 0x280958040>>
   |    |    |    |    |    | <UIViewControllerWrapperView: 0x1057bd850; frame = (0 0; 375 667); layer = <CALayer: 0x2808c1fe0>>
   |    |    |    |    |    |    | <UIView: 0x116871610; frame = (0 0; 375 667); autoresize = W+H; layer = <CALayer: 0x2808f3680>>
   |    |    |    |    |    |    |    | <MMTableView: 0x105cdc000; baseClass = UITableView; frame = (0 0; 375 667); clipsToBounds = YES; gestureRecognizers = <NSArray: 0x2806c83c0>; layer = <CALayer: 0x2808f3c60>; contentOffset: {0, -64}; contentSize: {375, 487}; adjustedContentInset: {64, 0, 0, 0}; dataSource: delegate[0x2806c8450], class[MMTableViewInfo]>
   |    |    |    |    |    |    |    |    | <UITableViewWrapperView: 0x105f10000; frame = (0 0; 375 667); gestureRecognizers = <NSArray: 0x2806baa90>; layer = <CALayer: 0x2808f0e40>; contentOffset: {0, 0}; contentSize: {375, 667}; adjustedContentInset: {0, 0, 0, 0}>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x119439110; baseClass = UITableViewCell; frame = (0 363; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808c2f60>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x1194394b0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x28064fe10>; layer = <CALayer: 0x2808c32a0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x119467e50; baseClass = UILabel; frame = (15 11.5; 104 21); text = '微信安全中心'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a63660>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808fa8e0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119439ea0; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808c3d20>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x11943a170; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808f5a60>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x1194680d0; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fbd80>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x119437ee0; baseClass = UITableViewCell; frame = (0 319; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808c3760>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x119438280; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x280657000>; layer = <CALayer: 0x2808c16e0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x1194675f0; baseClass = UILabel; frame = (15 11.5; 70 21); text = '微信密码'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a66b70>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f89c0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119438c70; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808c3f20>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119438f40; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808c1520>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x119467870; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fb9e0>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x1194366c0; baseClass = UITableViewCell; frame = (0 275; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808b8740>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x119436a60; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x28065e220>; layer = <CALayer: 0x2809556a0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x119466910; baseClass = UILabel; frame = (15 11.5; 52 21); text = '声音锁'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a67c00>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f9de0> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMBadgeView: 0x119466b90; baseClass = UIImageView; frame = (77 7; 49 30); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808fb500>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x119466d90; baseClass = UILabel; frame = (12.5 6.5; 24 15); text = 'new'; userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x282a67cf0>>
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119437a40; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808c3720>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119437d10; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808c1a80>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x116842810; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fb620>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x119467010; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fb680>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x1194351f0; baseClass = UITableViewCell; frame = (0 211; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2809c24a0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x119435590; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2805a4c30>; layer = <CALayer: 0x2809f4340>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x119465f80; baseClass = UILabel; frame = (15 11.5; 70 21); text = '邮箱地址'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a67890>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f9b60> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x119466200; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a677f0>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f9c40> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119436220; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2809c3140>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x1194364f0; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808a62a0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x116814110; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fb160>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x119433d20; baseClass = UITableViewCell; frame = (0 167; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x28089daa0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x1194340c0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2805a7db0>; layer = <CALayer: 0x28089cca0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x1194655f0; baseClass = UILabel; frame = (15 11.5; 75 21); text = 'Facebook'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a672f0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x119465870; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a673e0>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f8260> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119434d50; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28088a360>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119435020; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808ade20>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x119465080; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fad00>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x119432850; baseClass = UITableViewCell; frame = (0 123; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808e2b40>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x119432bf0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2805ad9b0>; layer = <CALayer: 0x2808e2bc0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x1194643e0; baseClass = UILabel; frame = (15 11.5; 52 21); text = '手机号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a66df0>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f9d60> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x119464660; baseClass = UILabel; frame = (231 0; 108 44); text = '+27723666587'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a66ee0>>
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119433880; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28089e2a0>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119433b50; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28089f560>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x119458ad0; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808f9640>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x119431210; baseClass = UITableViewCell; frame = (0 79; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808e20c0>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x1194315b0; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2805aeeb0>; layer = <CALayer: 0x2808e2140>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x119457be0; baseClass = UILabel; frame = (15 11.5; 45 21); text = 'QQ号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a66210>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808fa6e0> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x11945a770; baseClass = UILabel; frame = (293 0; 46 44); text = '未绑定'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a66850>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808fa4a0> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x1194323b0; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808e2900>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119432680; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808e2b20>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x11943c690; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808f93a0>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x119457e60; frame = (15 43.5; 360 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808f8220>>
   |    |    |    |    |    |    |    |    |    | <MMTableViewCell: 0x11942fbd0; baseClass = UITableViewCell; frame = (0 15; 375 44); text = ''; autoresize = W; layer = <CALayer: 0x2808e0f60>>
   |    |    |    |    |    |    |    |    |    |    | <UITableViewCellContentView: 0x11942ff70; frame = (0 0; 339 44); gestureRecognizers = <NSArray: 0x2805acff0>; layer = <CALayer: 0x2808e13e0>>
   |    |    |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x11943a340; baseClass = UILabel; frame = (15 11.5; 52 21); text = '微信号'; userInteractionEnabled = NO; tag = 9999; layer = <_UILabelLayer: 0x282a659a0>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f8460> (layer)
   |    |    |    |    |    |    |    |    |    |    |    | <MMCPLabel: 0x1194548b0; baseClass = UILabel; frame = (293 0; 46 44); text = '未设置'; autoresize = LM; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a66760>>
   |    |    |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808fa200> (layer)
   |    |    |    |    |    |    |    |    |    |    | <_UITableCellAccessoryButton: 0x119430d70; frame = (349 15; 11 14); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808e1fa0>>
   |    |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x119431040; frame = (0 0; 11 14); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808e2200>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x105775c30; frame = (0 0; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fa500>>
   |    |    |    |    |    |    |    |    |    |    | <UIView: 0x11943a5c0; frame = (0 43.5; 375 0.5); autoresize = W; tag = 124342; layer = <CALayer: 0x2808fa700>>
   |    |    |    |    |    |    |    |    | <UIView: 0x11942c8d0; frame = (0 0; 375 15); layer = <CALayer: 0x2808f1420>>
   |    |    |    |    |    |    |    |    | <_UIScrollViewScrollIndicator: 0x11942f5b0; frame = (3 597; 369 3); alpha = 0; autoresize = TM; layer = <CALayer: 0x2808e1c60>>
   |    |    |    |    |    |    |    |    |    | <UIView: 0x11942f750; frame = (0 0; 369 3); layer = <CALayer: 0x2808e25e0>>
   |    |    |    |    |    |    |    |    | <UIView: 0x119468240; frame = (0 407; 375 60); autoresize = W; layer = <CALayer: 0x2808fbdc0>>
   |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x1194683b0; baseClass = UILabel; frame = (20 6; 335 34); text = '如果遇到帐号信息泄露、忘记密码、诈骗等帐号安全问题...'; autoresize = W; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a61180>>
   |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808fa260> (layer)
   |    |    |    |    |    |    |    |    | <_UIScrollViewScrollIndicator: 0x11942f8c0; frame = (369 119; 3 481); alpha = 0; autoresize = LM; layer = <CALayer: 0x2808e2f80>>
   |    |    |    |    |    |    |    |    |    | <UIView: 0x11942fa60; frame = (0 0; 3 481); layer = <CALayer: 0x2808e3b00>>
   |    |    |    |    |    |    |    | <MMLoadingView: 0x11687bbc0; frame = (0 0; 375 667); hidden = YES; autoresize = W+H; layer = <CALayer: 0x2808879a0>>
   |    |    |    |    |    |    |    |    | <UIImageView: 0x11944db00; frame = (127.5 273.5; 120 120); opaque = NO; autoresize = LM+RM+TM+BM; userInteractionEnabled = NO; layer = <CALayer: 0x280887a20>>
   |    |    |    |    |    |    |    |    |    | <UIImageView: 0x11943bf90; frame = (30 20; 60 60); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x28088b200>>
   |    |    |    |    |    |    |    |    |    | <UIActivityIndicatorView: 0x11944f3c0; frame = (30 17; 60 60); hidden = YES; layer = <CALayer: 0x28088a3e0>>
   |    |    |    |    |    |    |    |    |    |    | <UIImageView: 0x11944f5c0; frame = (11 11; 37 37); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280889660>>
   |    |    |    |    |    |    |    |    |    | <MMUILabel: 0x11944f790; baseClass = UILabel; frame = (0 83; 120 25); text = '正在验证密码…'; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a1e940>>
   |    |    |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808f1e80> (layer)
   |    |    |    |    | <MMUINavigationBar: 0x1168bf770; baseClass = UINavigationBar; frame = (0 20; 375 44); opaque = NO; autoresize = W; tintColor = UIDeviceRGBColorSpace 0 0 0 1; gestureRecognizers = <NSArray: 0x2806652c0>; layer = <CALayer: 0x280958400>> forcedLegacyProvider
   |    |    |    |    |    | <_UIBarBackground: 0x1168bf9d0; frame = (0 -20; 375 64); userInteractionEnabled = NO; layer = <CALayer: 0x280958360>>
   |    |    |    |    |    |    | <_UIBarBackgroundShadowView: 0x1168c0350; frame = (0 64; 375 0.5); layer = <CALayer: 0x280958f20>> clientRequestedContentView effect=none
   |    |    |    |    |    |    |    | <_UIBarBackgroundShadowContentImageView: 0x1168c0870; frame = (0 0; 375 0.5); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x280959040>>
   |    |    |    |    |    |    | <UIVisualEffectView: 0x1168c0170; frame = (0 0; 375 64); layer = <CALayer: 0x280958cc0>> effect=none
   |    |    |    |    |    |    |    | <_UIVisualEffectBackdropView: 0x1168c0530; frame = (0 0; 375 64); autoresize = W+H; userInteractionEnabled = NO; layer = <UICABackdropLayer: 0x280958f40>>
   |    |    |    |    |    |    |    | <_UIVisualEffectSubview: 0x1168c06d0; frame = (0 0; 375 64); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x280959020>>
   |    |    |    |    |    | <MMTitleView: 0x1168fd9c0; frame = (187 4; 1 36); layer = <CALayer: 0x2808f0b60>>
   |    |    |    |    |    |    | <MMUILabel: 0x105777c50; baseClass = UILabel; frame = (-47 0; 95 36); text = '帐号与安全'; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282afe530>>
   |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808e2fc0> (layer)
   |    |    |    |    |    | <UIView: 0x116877c20; frame = (0 0; 58 44); tintColor = UIDeviceWhiteColorSpace 1 1; layer = <CALayer: 0x2808f0b00>>
   |    |    |    |    |    |    | <MMBarButton: 0x1168b3900; baseClass = UIButton; frame = (10 0; 48 44); opaque = NO; layer = <CALayer: 0x2808f37e0>>
   |    |    |    |    |    |    |    | <UIImageView: 0x11942f2c0; frame = (0 7; 15 30); clipsToBounds = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808e1c40>>
   |    |    |    |    |    |    |    | <UIButtonLabel: 0x1168b1dc0; frame = (15 12.5; 33 20); text = '设置'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282aea760>>
   |    |    |    |    |    |    |    |    | <_UILabelContentLayer: 0x2808e1be0> (layer)
   |    |    |    |    |    | <UIView: 0x1168bfd10; frame = (0 -20; 375 64); userInteractionEnabled = NO; layer = <CALayer: 0x280959820>>
   |    |    |    |    |    |    | <CAGradientLayer: 0x2809592a0> (layer)
   |    |    |    |    |    | <UINavigationBarBackIndicatorView: 0x1168bfe80; frame = (8 11.5; 13 21); alpha = 0; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280958f00>>
   |    | <UITabBar: 0x11687fae0; frame = (0 618; 375 49); hidden = YES; autoresize = W+TM; tintColor = UIDeviceRGBColorSpace 0.2 0.65098 1 1; gestureRecognizers = <NSArray: 0x280651620>; layer = <CALayer: 0x2808819c0>>
   |    |    | <_UIBarBackground: 0x1168b63a0; frame = (0 0; 375 49); userInteractionEnabled = NO; layer = <CALayer: 0x280881a20>>
   |    |    |    | <_UIBarBackgroundShadowView: 0x11682ac80; frame = (0 -0.5; 375 0.5); layer = <CALayer: 0x28088d820>> clientRequestedContentView effect=none
   |    |    |    |    | <_UIBarBackgroundShadowContentImageView: 0x116878960; frame = (0 0; 375 0.5); autoresize = W+H; userInteractionEnabled = NO; layer = <CALayer: 0x28088da20>>
   |    |    |    | <UIImageView: 0x116d2bc30; frame = (0 0; 375 49); userInteractionEnabled = NO; layer = <CALayer: 0x2808e9240>>
   |    |    | <UITabBarButton: 0x116891210; frame = (96 1; 90 48); opaque = NO; layer = <CALayer: 0x280882b60>>
   |    |    |    | <UITabBarSwappableImageView: 0x1168308d0; frame = (31.5 6.5; 27 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x280882be0>>
   |    |    |    | <UITabBarButtonLabel: 0x1168914d0; frame = (29.5 34.5; 31 12); text = '通讯录'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282adfa20>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088dc60> (layer)
   |    |    | <UITabBarButton: 0x116891780; frame = (190 1; 89 48); opaque = NO; layer = <CALayer: 0x280881f00>>
   |    |    |    | <UITabBarSwappableImageView: 0x116864630; frame = (32.5 6.5; 23 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x2808824c0>>
   |    |    |    | <UITabBarButtonLabel: 0x116891a40; frame = (34 34.5; 20.5 12); text = '发现'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282adeda0>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088d520> (layer)
   |    |    | <UITabBarButton: 0x11685d590; frame = (283 1; 90 48); opaque = NO; layer = <CALayer: 0x2808823a0>>
   |    |    |    | <UITabBarSwappableImageView: 0x116864830; frame = (33 6.5; 23 23); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280882360>>
   |    |    |    | <UITabBarButtonLabel: 0x11685d850; frame = (39.5 34.5; 10.5 12); text = '我'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282adea80>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088c1e0> (layer)
   |    |    | <UITabBarButton: 0x106143600; frame = (2 1; 90 48); opaque = NO; layer = <CALayer: 0x2808f46e0>>
   |    |    |    | <UITabBarSwappableImageView: 0x106156680; frame = (32 6.5; 25 23); opaque = NO; userInteractionEnabled = NO; tintColor = UIDeviceWhiteColorSpace 0.572549 0.85; layer = <CALayer: 0x2808f4600>>
   |    |    |    | <UITabBarButtonLabel: 0x1061563d0; frame = (34.5 34.5; 20.5 12); text = '微信'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a31310>>
   |    |    |    |    | <_UILabelContentLayer: 0x2808f4ea0> (layer)
   |    |    |    | <_UIBadgeView: 0x106156880; frame = (52 2; 18 18); text = '5'; userInteractionEnabled = NO; layer = <CALayer: 0x2808f45e0>>
   |    |    |    |    | <UILabel: 0x106156a30; frame = (5 1; 8 16); text = '5'; opaque = NO; userInteractionEnabled = NO; layer = <_UILabelLayer: 0x282a30f00>>
   |    |    | <MMBadgeView: 0x116845af0; baseClass = UIImageView; frame = (49 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280882fc0>>
   |    |    |    | <MMUILabel: 0x116846500; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x282adf250>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088d9c0> (layer)
   |    |    | <MMBadgeView: 0x116846780; baseClass = UIImageView; frame = (143 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x2808818e0>>
   |    |    |    | <MMUILabel: 0x116846980; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x282adc870>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088d9a0> (layer)
   |    |    | <MMBadgeView: 0x116846c00; baseClass = UIImageView; frame = (237 -5; 30 30); hidden = YES; opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280882740>>
   |    |    |    | <MMUILabel: 0x116846e00; baseClass = UILabel; frame = (0 0; 0 0); userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x282adf2f0>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088da40> (layer)
   |    |    | <MMBadgeView: 0x116847080; baseClass = UIImageView; frame = (330 1; 20 20); opaque = NO; userInteractionEnabled = NO; layer = <CALayer: 0x280881800>>
   |    |    |    | <MMUILabel: 0x11682de20; baseClass = UILabel; frame = (0 0; 0 0); hidden = YES; userInteractionEnabled = NO; tag = 10032; layer = <_UILabelLayer: 0x282adf5c0>>
   |    |    |    |    | <_UILabelContentLayer: 0x28088d900> (layer)